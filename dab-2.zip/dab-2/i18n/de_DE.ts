<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>RadioInterface</name>
    <message>
        <location filename="../radio.cpp" line="429"/>
        <location filename="../radio.cpp" line="847"/>
        <location filename="../radio.cpp" line="861"/>
        <location filename="../radio.cpp" line="875"/>
        <location filename="../radio.cpp" line="889"/>
        <location filename="../radio.cpp" line="905"/>
        <location filename="../radio.cpp" line="920"/>
        <location filename="../radio.cpp" line="934"/>
        <location filename="../radio.cpp" line="948"/>
        <location filename="../radio.cpp" line="962"/>
        <location filename="../radio.cpp" line="976"/>
        <location filename="../radio.cpp" line="998"/>
        <location filename="../radio.cpp" line="1018"/>
        <location filename="../radio.cpp" line="1036"/>
        <location filename="../radio.cpp" line="1056"/>
        <location filename="../radio.cpp" line="1460"/>
        <location filename="../radio.cpp" line="1734"/>
        <location filename="../radio.cpp" line="1847"/>
        <location filename="../radio.cpp" line="1999"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="430"/>
        <source>Opening  input stream failed
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="848"/>
        <source>Airspy or Airspy mini not found
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="862"/>
        <source>hackrf not found
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="876"/>
        <source>no soapy device found
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="890"/>
        <source>no lime device found
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="906"/>
        <source>extio: no luck
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="921"/>
        <source>rtl_tcp: no luck
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="935"/>
        <location filename="../radio.cpp" line="949"/>
        <source>SDRplay: no library or device
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="963"/>
        <source>elad-s1: no library or device
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="977"/>
        <source>DAB stick not found! Please use one with RTL2832U or similar chipset!
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="987"/>
        <location filename="../radio.cpp" line="1007"/>
        <location filename="../radio.cpp" line="1026"/>
        <location filename="../radio.cpp" line="1044"/>
        <source>Open file ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="989"/>
        <source>xml data (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="1009"/>
        <source>iq data (*.iq)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="999"/>
        <location filename="../radio.cpp" line="1019"/>
        <location filename="../radio.cpp" line="1037"/>
        <location filename="../radio.cpp" line="1057"/>
        <source>file not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="1028"/>
        <source>raw data (*.raw)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="1046"/>
        <location filename="../radio.cpp" line="1362"/>
        <source>raw data (*.sdr)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="1453"/>
        <source>aac data (*.aac)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="1848"/>
        <source>unknown bitrate for this program
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="1903"/>
        <source>sdr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="1904"/>
        <source>still insufficient data for this service
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="1735"/>
        <source>Incorrect preset
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="622"/>
        <location filename="../radio.cpp" line="1360"/>
        <location filename="../radio.cpp" line="1406"/>
        <location filename="../radio.cpp" line="1451"/>
        <source>Save file ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="1408"/>
        <source>PCM wave file (*.wav)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="625"/>
        <source>Text (*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="2000"/>
        <source>Oops, ensemble not yet recognized
select service manually
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../radio.cpp" line="1598"/>
        <source>Are you sure?
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>airspyHandler</name>
    <message>
        <location filename="../devices/airspy-handler/airspy-handler.cpp" line="783"/>
        <source>Save file ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-handler.cpp" line="785"/>
        <source>Xml (*.uff)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>airspyWidget</name>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="14"/>
        <source>airspy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="30"/>
        <source>sensitivity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="118"/>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="270"/>
        <source>lna gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="131"/>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="283"/>
        <source>mixer gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="144"/>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="296"/>
        <source>vga gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="166"/>
        <source>linearity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="302"/>
        <source>classic view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="333"/>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="458"/>
        <source>lna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="397"/>
        <source>mixer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="429"/>
        <source>vga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="471"/>
        <source>mixer </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="484"/>
        <source>bias</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="512"/>
        <source>A I R S P Y  handler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="525"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dumps the raw input from the airspy into a self describing file (with header in xml format containing recorded time, container format, frequency, device name, Qt-DAB version)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Opens a &apos;Save as ...&apos; dialog. Press again to stop recording.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Very experimental! The resulting file can be read-in by using the xml file handler (if configured)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Warning: Produces large files!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Speichert die Eingangsrohdaten vom Airspy in eine selbsterklärende Datei (mit Header im xml-Format, der die Aufnahmezeit, Containerformat, Frequenz, Empfänger, Qt-DAB-Version anzeigt)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Öffnet einen &quot;Speichern unter ...&quot; dialog. Noch einmal klicken, um die Aufnahme zu beenden.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Sehr experimentell! Die erzeugte Datei kann über die xml file Eingangsfunktion geladen werden (falls konfiguriert)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Warnung: Erstellt große Dateien!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/airspy-handler/airspy-widget.ui" line="528"/>
        <source>dump</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>audioDescription</name>
    <message>
        <location filename="../forms/audio-description.ui" line="14"/>
        <source>audio description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="87"/>
        <location filename="../forms/audio-description.ui" line="101"/>
        <location filename="../forms/audio-description.ui" line="115"/>
        <location filename="../forms/audio-description.ui" line="129"/>
        <location filename="../forms/audio-description.ui" line="143"/>
        <location filename="../forms/audio-description.ui" line="157"/>
        <location filename="../forms/audio-description.ui" line="171"/>
        <location filename="../forms/audio-description.ui" line="185"/>
        <location filename="../forms/audio-description.ui" line="199"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="136"/>
        <source>bitRate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="94"/>
        <source>subchannel Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="47"/>
        <source>service name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="62"/>
        <source>DAB type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="108"/>
        <source>Start Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="122"/>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="150"/>
        <source>Protection level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="164"/>
        <source>ProgramType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="178"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="192"/>
        <source>alternative FM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="29"/>
        <source>audio service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/audio-description.ui" line="80"/>
        <source>serviceId</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>correlationWidget</name>
    <message>
        <location filename="../correlation-viewer/correlation-widget.ui" line="14"/>
        <source>sync correlation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../correlation-viewer/correlation-widget.ui" line="26"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Impulse sync display (CIR)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Impulsanzeige (CIR)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../correlation-viewer/correlation-widget.ui" line="33"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If more than one transmitter is detected, the relative distance - in msec - is shown between the arrival time of the data of the transmitter that is used, and the arrival time of the data of the other transmitter.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Falls mehr als eine Sendeanlage erkannt wird, wird die relative Entfernung - in msec - zwischen &lt;/p&gt;&lt;p&gt;des Empfangs der Daten zwischen der verwendeten und der übrigen Sendeanlage angezeigt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spectrum display, shows the frequency spectrum from the channel currently being received.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spektrumsanzeige, zeigt das Frequenzspektrum des derzeit empfangenen Kanals an.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If more than one transmitter is detected, the relative distance - in msec - is shown between&lt;/p&gt;&lt;p&gt;the arrival time of the data of the transmitter that is used, and the arrival time of the data of&lt;/p&gt;&lt;p&gt;the other transmitter.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Falls mehr als eine Sendeanlage erkannt wird, wird die relative Entfernung - in msec - zwischen &lt;/p&gt;&lt;p&gt;des Empfangs der Daten zwischen der verwendeten und der übrigen Sendeanlage angezeigt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>dabradio</name>
    <message>
        <location filename="../forms/dabradio.ui" line="390"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Indicator for time synchronization&lt;/p&gt;&lt;p&gt;Green means that the software recognizes that there are DAB frames, not necessarily that the software is able to decode the DAB stream.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Indikator für Synchronisation&lt;/p&gt;&lt;p&gt;Grün bedeutet, die Software erkennt, dass hier DAB Frames sind, das heißt jedoch nicht, dass sie sie auch dekodieren kann.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="396"/>
        <source>Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Stereo label&lt;/p&gt;&lt;p&gt;Green means that the program is in stereo.&lt;br/&gt;Red means no audio or mono transmission.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Stereoanzeige&lt;/p&gt;&lt;p&gt;Grün bedeutet, das Programm ist in stereo.&lt;br/&gt;Rot bedeutet entweder kein Audio oder nur Monoausstrahlung.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="197"/>
        <source>©</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="160"/>
        <source>run-time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ensemble ID&lt;/p&gt;&lt;p&gt;The hecadecimal number shows the ensemble ID.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ensemble ID&lt;/p&gt;&lt;p&gt;Die Hexadezimalzahl zeigt die Ensemble ID.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="255"/>
        <source>Offset [Hz]:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="267"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Coarse offset, indicates - in Hz - the frequency offset. Coarse offset is in large steps, where a step is the distance - in Hz - between two subsequent carriers in the ofdm signal.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Grober Offset, zeigt - in Hz - den Frequenzoffset an. Der Offset geschieht in großen Schritten, wobei ein Schritt der Abstand - in Hz - zwischen zwei aufeinander folgenden Trägern des OFDM Signal ist.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="218"/>
        <source>SNR: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;A Signal to Noise (SNR) indicator&lt;/p&gt;&lt;p&gt;In general: higher is better. But do not take the value as a serious measure of the SNR, it strongly depends on the device and the amount of filtering applied in the device!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ein Signal-Rausch-Abstand (SNR) Indikator&lt;/p&gt;&lt;p&gt;Allgemein gilt: Je größer, desto besser. Bitte die Werte nicht als echte SNR-Werte verstehen, sie hängen stark vom Empfänger und der Anzahl der Filter im Gerät ab!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="595"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If configured - pushing this button will switch the spectrum display between &amp;quot;regular&amp;quot; and a spectrum showing the &amp;quot;null symbol&amp;quot; period. In the console window the pattern, main ID and sub ID of the TII will be displayed.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Falls es konfiguriert wurde, springt bei Drücken dieser Schaltfläche die Spektrumanzeige zwischen der &amp;quot;regulären&amp;quot; und des &amp;quot;Nullsymbols&amp;quot; hin und her. Auf der Konsole wird das Muster (Pattern), die main ID und die sub ID des TII ausgegeben.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="598"/>
        <source>TII</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="725"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;history feature. The software maintains a list of all services encountered. Touching this button will show (hide) the list. By clicking with the left mouse button the software will try to select the service pointed to, by clicking with the ruight mouse button the lit will be deleted.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Historiefunktion. Die Software speichert eine Liste aller bisher verwendeten Services. Ein Klick auf diesen Button zeigt (versteckt) die Liste. Bei einem Linksklick versucht die Software das ausgewählte Service abzuspielen, bei einem Rechtsklick wird der Eintrag gelöscht.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="728"/>
        <source>xx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="746"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This will open a &apos;save as ... dialog&apos; where you can select a file to store a description of the content of the current DAB ensemble (Audio and Data) in a text file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Das führt zu einem &quot;Speichern unter ...&quot; Dialog, wo Sie einen Dateinamen auswählen können, um den Inhalt des gerade empfangenen DAB Pakets (Audio und Daten) in eine Textdatei zu schreiben.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="768"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Push this button to save audio output into a file. First push will show a menu for file selection. Push again to stop recording.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Schaltfläche drücken, um das Audio in eine Datei zu speichern. Es erscheint ein Fenster, um einen Dateinamen auszuwählen. Erneut drücken, um den Speichervorgang zu beenden.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="812"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Push this button to save the raw input. Pushing will cause a menu to appear where a filename can be selected. Please note the big filesizes!&lt;/p&gt;&lt;p&gt;Push again to stop recording. You can reload it by using the file input (*.sdr) option. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Schaltfläche drücken, um die Rohdaten in eine Datei zu speichern. Es erscheint ein Fenster, um einen Dateinamen auszuwählen. Bitte beachten Sie, das sehr große Dateien entstehen werden! Erneut drücken, um den Speichervorgang zu beenden. Sie können später die erstellte *.sdr-Datei wieder laden.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="815"/>
        <source>Raw dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="642"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The spectrum and the constellation of the DAB signal is shown when pressing this button. Pressing it&lt;/p&gt;&lt;p&gt;again will cause the spectrum and constellation to be invisible.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Schaltfläche drücken, um das Spektrum und das Konstellationsdiagramm anzuzeigen. Nochmals drücken, um das Fenster wieder zu schließen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="645"/>
        <source>Spectrum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This will open a &apos;save as ... dialog&apos; where you can store the content of the current DAB ensemble (Audio and Data) in a text file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Schaltfläche drücken, um einen &apos;Speichern unter ...&apos; Dialog anzuzeigen, bei dem der Inhalt (Informationen über Audio und Daten) des aktuellen DAB Ensembels in eine Textdatei geschrieben wird.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="749"/>
        <source>Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="674"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a device (channel) for the audio output. On program start up a default is chosen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wählen Sie ein Gerät für die Audioausgabe. Bei Programmstart wird die Standardeinstellung verwendet.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="678"/>
        <source>Audio Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a DAB band.&lt;/p&gt;&lt;p&gt;The default is VHF Band III (174–230 MHz).&lt;/p&gt;&lt;p&gt;Alternatively, the L Band may be selected (1452 bis 1492 MHz, but only used in very few countries like Czech Republic).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Auswahl des DAB Frequenzbandes.&lt;/p&gt;&lt;p&gt;Standardmäßig ist es das VHF-Band III (174–230 MHz).&lt;/p&gt;&lt;p&gt;Auf Wunsch kann aber auch das L-Band ausgewählt werden (1452 bis 1492 MHz, wird jedoch nur in sehr wenigen Ländern verwendet, wie zB der Tschechischen Republik).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the DAB channel.&lt;/p&gt;&lt;p&gt;This depends on the band chosen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;DAB Kanal auswählen.&lt;/p&gt;&lt;p&gt;Hängt vom verwendeten DAB Frequenzband ab.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="698"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select the input device. The devices shown are configured. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Gerät wählen. Nur die angezeigten Geräte wurden konfiguriert. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="180"/>
        <source>localTime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="20"/>
        <source>Qt-DAB-3.2-Beta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="66"/>
        <source>Presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="78"/>
        <source>Select the previous service on the list of services (the previous one of the first element is the last element of the list).</source>
        <translation>Wählt das vorige Service aus der Liste aus (das vorige des ersten ist das letzte in der Liste).</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="81"/>
        <location filename="../forms/dabradio.ui" line="117"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="88"/>
        <source>Select the next service on the list of services (the next of the last element is the first element).</source>
        <translation>Wählt das nächste Service aus der Liste aus (das nächste des letzten ist das erste in der Liste).</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="91"/>
        <location filename="../forms/dabradio.ui" line="127"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="100"/>
        <source>Channel selector.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="104"/>
        <source>channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="114"/>
        <source>Select the previous channel.</source>
        <translation>Wählt den vorigen DAB-Kanal.</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="124"/>
        <source>Select the next channel of the list maintained in the channel selector.</source>
        <translation>Wählt den nachfolgenden DAB-Kanal.</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="170"/>
        <source>Local time is the time as received from the transmission. If you are running recordings, then
it is definitely not the time on your clock.</source>
        <translation>Lokale Zeit laut DAB-Datenstrom. Falls eine Aufzeichnung abgespielt wird, dann ist es nicht die aktuelle Uhrzeit.</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="194"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Qt-DAB copyright:&lt;/p&gt;&lt;p&gt;J van Katwijk, Lazy Chair Computing. J.vanKatwijk@gmail.com&lt;/p&gt;&lt;p&gt;Copyright of the Qt toolkit used: the Qt Company&lt;/p&gt;&lt;p&gt;Copyright of the libraries used for SDRplay, rtl-sdr based sticks, AIRspy, portaudio, libsndfile and libsamplerate and libfftw3 to their developers&lt;/p&gt;&lt;p&gt;Copyright of the MP2 library used Martin J Fiedler&lt;/p&gt;&lt;p&gt;Copyright of the firecode checker: Gnu Radio&lt;/p&gt;&lt;p&gt;Copyright of the Reed Solomon Decoder software: Phil Karns&lt;/p&gt;&lt;p&gt;Copyright of the code to create a correct header for the AAC files: Stefan Poeschel&lt;/p&gt;&lt;p&gt;All copyrights gratefully acknowledged&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;The current layout of the GUI is based on a design of Luo Zhang, Thanks&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Qt-DAB (an SDR-J program) is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="231"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;A Signal to Noise (SNR) indicator&lt;/p&gt;&lt;p&gt;In general: higher is better. But do not take the value as a serious measure of the SNR. The value is computed ad ration between the signal strength overall amd the signal strength during the null period of a DAB frame.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ein Signal-Rausch-Abstand (SNR) Indikator&lt;/p&gt;&lt;p&gt;Allgemein gilt: Je größer, desto besser. Bitte die Werte nicht als echte SNR-Werte verstehen, sie hängen stark vom Empfänger und der Anzahl der Filter im Gerät ab!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="290"/>
        <source>Frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="321"/>
        <source>The total load on the processor, not just from running this application.</source>
        <translation>Die CPU Last des gesamten Systems, nicht nur von diesem Programm.</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="340"/>
        <source>CPU load (%):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="406"/>
        <source>FIC </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="551"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Push this button to reset, i.e. restart synchronization.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Für einen Reset drücken, zB um neu zu synchronisieren.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="554"/>
        <source>reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="617"/>
        <source>Touching this button will show (or hide) the resulting correlation of the first datablock of the DAB
ensemble with the values as they should be. The &quot;peaks&quot; (if any) show the samples where
the correlation is strongest. More than one peak shows more than one transmitter within
the reach of this receiver.</source>
        <translation>Drücken Sie, um das Korrelationsdiagramm anzuzeigen. Die Spitzen (falls verfügbar) zeigen die Samples mit der stärksten Korrelation. Mehrere Spitzen bedeuten, dass mehrere Sendeanlagen empfangen werden.</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="623"/>
        <source>corr-result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="652"/>
        <source>Hide or show the widget for device control.</source>
        <translation>Anzeigen oder Verstecken des Gerätekontrollfensters.</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="655"/>
        <source>show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="702"/>
        <source>Input Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="707"/>
        <source>file input (.raw)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="712"/>
        <source>file input (.iq)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="717"/>
        <source>file input (.sdr)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="771"/>
        <source>audio dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="790"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Decoding of DAB+ audio services results first in the extraction of AAC frames from the input, then conversion of the AAC frames to PCM frames, and then sending these PCM frames to the soundcard. It is possible, already for a long time, to save the PCM frames into a &amp;quot;.wav&amp;quot; file,&lt;/p&gt;&lt;p&gt;It is now also possible to save the AAC frames into a file. Writing AAC frames is under control of this button. Touching it will show a menu for file selection, after selecting a file, the AAC frames will be written to this file, until the button is touched again.&lt;/p&gt;&lt;p&gt;Code for converting the aac headers to ones that can be understood by e.g. VLC is from Stefan Poeschel. All rights gratefully acknowledged&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Eine Dekodierung von DAB+ Audioservices geschieht zuerst mit der Auswertung von AAC frames aus der Eingabe, dann Konvertierung der AAC Frames in PCM Frames und dann werden diese PCM Frames an die Soundkarte weitergegeben. Seit einiger Zeit ist es möglich, die PCM Frames in eine &amp;quot;.wav&amp;quot; Datei zu speichern.&lt;/p&gt;&lt;p&gt;Nun ist es auch möglich, die AAC Frames in eine Datei mit Hilfe dieser Schaltfläche zu speichern. Ein Klick frage nach einem Dateinamen, dann werden die AAC Frames geschrieben, bis die Schaltfläche erneut gedrückt wird.&lt;/p&gt;&lt;p&gt;Der Code, um die AAC Headers in jene, die zB VLC versteht, umzuwandeln wurde von Stefan Pöschel dankeswerterweise zur Verfügung gestellt.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="793"/>
        <source>frame dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="573"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Push this button for starting a scan over the channels in the current selected band (default VHF Band III or optionally L-Band)&lt;/p&gt;&lt;p&gt;Scanning will continue until an active DAB or DAB+ signal is found.&lt;/p&gt;&lt;p&gt;Push again to stop scanning.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Schaltfläche drücken, um einen Suchlauf über das gewählte DAB Frequenzband (standardmäßig VHF Band III bzw. optional das L-Band) zu starten.&lt;/p&gt;&lt;p&gt;Der Suchlauf wird, solange ein aktives DAB or DAB+ Signal gefunden wurde, fortgesetzt.&lt;/p&gt;&lt;p&gt;Erneut drücken, um den Suchlauf abzubrechen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="47"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Selecting a service is by clicking with the &lt;span style=&quot; font-weight:600; font-style:italic;&quot;&gt;left &lt;/span&gt;mouse button on the name of the service.&lt;/p&gt;&lt;p&gt;Clicking with the &lt;span style=&quot; font-weight:600; font-style:italic;&quot;&gt;right mouse button on the name of the selected service &lt;/span&gt;in this list will add the service to the presets.&lt;/p&gt;&lt;p&gt;Clicking with the right mouse button on the name of any other of the listed services will show some data on that service.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Die Auswahl eines Services geschieht durch einen &lt;span style=&quot; font-weight:600; font-style:italic;&quot;&gt;Linksklick &lt;/span&gt;auf den Namen des Services.&lt;/p&gt;&lt;p&gt;Ein &lt;span style=&quot; font-weight:600; font-style:italic;&quot;&gt;Rechtsklick auf den Namen des Services &lt;/span&gt;fügt diesen zur Favoritenliste hinzu. &lt;/p&gt;&lt;p&gt;Ein Rechtsklick auf den Namen eines anderen Service zeigt einige Details an.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="62"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Presets are short cuts to services - possibly in ensembles in different channels - that are obtained by clicking with the &lt;span style=&quot; font-weight:600; font-style:italic;&quot;&gt;right &lt;/span&gt;mouse button on the name of the service &lt;span style=&quot; font-weight:600; font-style:italic;&quot;&gt;in the list of services when selected&lt;/span&gt;.&lt;/p&gt;&lt;p&gt;Removing a name from the presets is by selecting the service in this combobox and pressing the shift+delete combination.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Favoriten sind Services aus verschiedenen Ensembles - auch auf unterschiedlichen Kanälen - und werden durch einen &lt;span style=&quot; font-weight:600; font-style:italic;&quot;&gt;Rechtsklick &lt;/span&gt;auf den Name des Services erstellt, &lt;span style=&quot; font-weight:600; font-style:italic;&quot;&gt;sofern er vorher markiert wurde.&lt;/span&gt;.&lt;/p&gt;&lt;p&gt;Einen Favoriten zu entfernen geschieht durch die Auswahl in dieser Combobox und durch die Tastenkombination Umschalt + Entfernen (Shift + Del).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="302"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Frequency in MHz (only available from live sources)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Frequenz in MHz (nur bei Livequellen verfügbar)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="439"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ensemble Label and Ensemble ID are shown here.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ensemble Label und Ensemble ID werden hier gezeigt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="454"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Transmitter Identification Information (tii) is shown here. If more than one transmitter are being received, only the strongest will be shown.&lt;/p&gt;&lt;p&gt;Note that not all transmitters might have its own code.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Transmitter Identification Information (tii) wird hier angezeigt. Falls mehr als eine Sendeanlage empfangen wird, wird nur die stärkste angezeigt.&lt;/p&gt;&lt;p&gt;Beachten Sie, dass nicht alle Sendeanlagen ihren eigenen Code haben könnten.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="476"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Long label of the selected service&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Long label des ausgewählten Services&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="499"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dynamic Labels (DLS)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dynamic Labels (DLS)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="576"/>
        <source>Scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="535"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Push this button for further technical information about the selected program&lt;/p&gt;&lt;p&gt;Push again for closing the pop-up-window.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Schaltfläche drücken, um technische Information über das gewählte Programm anzuzeigen.&lt;/p&gt;&lt;p&gt;Erneut drücken, um das Fenster zu schließen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/dabradio.ui" line="538"/>
        <source>Detail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Reset player&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zurücksetzen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Push this button for selecting the next channel in the current band.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Schaltfläche drücken, um den nächsten DAB Kanal im gewählten Frequenzband auszuwählen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>dabstickWidget</name>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-widget.ui" line="14"/>
        <source>RT2832 dabstick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-widget.ui" line="85"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dumps the raw input from the rtlsdr dongle into a self describing file (with header in xml format containing recorded time, container format, frequency, device name, Qt-DAB version)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Opens a &apos;Save as ...&apos; dialog. Press again to stop recording.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Very experimental! The resulting file can be read-in by using the xml file handler (if configured)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Warning: Produces large files!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Speichert die Eingangsrohdaten vom rtlsdr Dongle in eine selbsterklärende Datei (mit Header im xml-Format, der die Aufnahmezeit, Containerformat, Frequenz, Empfänger, Qt-DAB-Version anzeigt)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Öffnet einen &quot;Speichern unter ...&quot; dialog. Noch einmal klicken, um die Aufnahme zu beenden.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Sehr experimentell! Die erzeugte Datei kann über die xml file Eingangsfunktion geladen werden (falls konfiguriert)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Warnung: Erstellt große Dateien!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-widget.ui" line="88"/>
        <source>dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-widget.ui" line="95"/>
        <source>dabstick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-widget.ui" line="22"/>
        <source>ppm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-widget.ui" line="49"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Set gain in dB, only possible values are displayed.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Verstärkung in dB auswählen, nur mögliche Werte werden angezeigt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-widget.ui" line="58"/>
        <source>gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-widget.ui" line="72"/>
        <source>autogain_off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-widget.ui" line="77"/>
        <source>autogain_on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-widget.ui" line="112"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Device name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Gerätename&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>dataDescription</name>
    <message>
        <location filename="../forms/data-description.ui" line="14"/>
        <source>data description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/data-description.ui" line="47"/>
        <location filename="../forms/data-description.ui" line="62"/>
        <location filename="../forms/data-description.ui" line="87"/>
        <location filename="../forms/data-description.ui" line="101"/>
        <location filename="../forms/data-description.ui" line="115"/>
        <location filename="../forms/data-description.ui" line="129"/>
        <location filename="../forms/data-description.ui" line="143"/>
        <location filename="../forms/data-description.ui" line="157"/>
        <location filename="../forms/data-description.ui" line="171"/>
        <location filename="../forms/data-description.ui" line="185"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/data-description.ui" line="136"/>
        <source>bitRate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/data-description.ui" line="94"/>
        <source>subchannel Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/data-description.ui" line="108"/>
        <source>Start Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/data-description.ui" line="122"/>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/data-description.ui" line="150"/>
        <source>Protection level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/data-description.ui" line="164"/>
        <source>packet address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/data-description.ui" line="29"/>
        <source>data service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/data-description.ui" line="178"/>
        <source>FEC scheme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/data-description.ui" line="80"/>
        <source>serviceId</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>extioHandler</name>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="123"/>
        <source>load file ..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="126"/>
        <source>libs (Extio*.dll)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="128"/>
        <source>libs (*.so)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="132"/>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="152"/>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="158"/>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="171"/>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="179"/>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="191"/>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="206"/>
        <source>sdr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="133"/>
        <source>incorrect filename
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="153"/>
        <source>loading dll failed
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="159"/>
        <source>loading functions failed
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="172"/>
        <source>init failed
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="180"/>
        <source>Opening hardware failed
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="192"/>
        <source>please select an inputrate 2048000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/extio-handler/extio-handler.cpp" line="207"/>
        <source>device not supported
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>filereaderWidget</name>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Path to file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad zur Datei&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>hackrfHandler</name>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-handler.cpp" line="585"/>
        <source>Save file ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-handler.cpp" line="587"/>
        <source>Xml (*.uff)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>hackrfWidget</name>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-widget.ui" line="14"/>
        <source>HACKRF control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-widget.ui" line="22"/>
        <source>Ant Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-widget.ui" line="32"/>
        <source>Amp Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-widget.ui" line="39"/>
        <source>ppm Correction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-widget.ui" line="70"/>
        <source>Serial Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-widget.ui" line="89"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dumps the raw input from the HackRF into a self describing file (with header in xml format containing recorded time, container format, frequency, device name, Qt-DAB version)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Opens a &apos;Save as ...&apos; dialog. Press again to stop recording.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Very experimental! The resulting file can be read-in by using the xml file handler (if configured)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Warning: Produces large files!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Speichert die Eingangsrohdaten vom HackRF in eine selbsterklärende Datei (mit Header im xml-Format, der die Aufnahmezeit, Containerformat, Frequenz, Empfänger, Qt-DAB-Version anzeigt)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Öffnet einen &quot;Speichern unter ...&quot; dialog. Noch einmal klicken, um die Aufnahme zu beenden.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Sehr experimentell! Die erzeugte Datei kann über die xml file Eingangsfunktion geladen werden (falls konfiguriert)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Warnung: Erstellt große Dateien!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-widget.ui" line="92"/>
        <source>Dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-widget.ui" line="126"/>
        <source>vga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/hackrf-handler/hackrf-widget.ui" line="166"/>
        <source>lna</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>impulseWidget</name>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spectrum display, shows the frequency spectrum from the channel currently being received.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Anzeige des Spektrums, zeigt das Spektrum des aktuell gewählten DAB Kanals an.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>limeHandler</name>
    <message>
        <location filename="../devices/lime-handler/lime-handler.cpp" line="483"/>
        <source>Save file ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/lime-handler/lime-handler.cpp" line="485"/>
        <source>Xml (*.uff)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>rtl_dongleSelect</name>
    <message>
        <location filename="../devices/rtlsdr-handler/rtl-dongleselect.cpp" line="36"/>
        <source>dongle select</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>rtl_tcp_client</name>
    <message>
        <location filename="../devices/rtl_tcp/rtl_tcp_client.cpp" line="139"/>
        <source>sdr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtl_tcp/rtl_tcp_client.cpp" line="140"/>
        <source>connection failed
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>rtl_tcp_widget</name>
    <message>
        <location filename="../devices/rtl_tcp/rtl_tcp-widget.ui" line="14"/>
        <source>rtl-tcp control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtl_tcp/rtl_tcp-widget.ui" line="41"/>
        <source>rtl_tcp_client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtl_tcp/rtl_tcp-widget.ui" line="67"/>
        <source>connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtl_tcp/rtl_tcp-widget.ui" line="80"/>
        <source>disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtl_tcp/rtl_tcp-widget.ui" line="132"/>
        <source> gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtl_tcp/rtl_tcp-widget.ui" line="145"/>
        <source>ppm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtl_tcp/rtl_tcp-widget.ui" line="171"/>
        <source>Offset</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>rtlsdrHandler</name>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-handler.cpp" line="570"/>
        <source>Save file ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/rtlsdr-handler/rtlsdr-handler.cpp" line="572"/>
        <source>Xml (*.uff)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>scopeWidget</name>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spectrum display, shows the frequency spectrum from the channel currently being received.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spektrumanzeige, zeigt das Frequenzspektrum des aktuell empfangenen Kanals an.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../spectrum-viewer/scopewidget.ui" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spectrum view&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spektrumanzeige&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../spectrum-viewer/scopewidget.ui" line="55"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Constellation diagram&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Konstellationsdiagramm&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../spectrum-viewer/scopewidget.ui" line="67"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zoom in/out&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Hinein-/Herauszoomen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Constellation diagram, obtained from the first data block in a DAB frame. What is shown are the constellations of the carriers in the decoded OFDM symbol. &lt;/p&gt;&lt;p&gt;In DAB the bits are encoded as (1, 1), (1, -1), (-1, -1) and (1,1), so ideally there are 4 points, one in each corner. The quality of the signal is inverse to the clouds that are visible. The number indicated below this &amp;quot;cloud picture&amp;quot; shows the standard deviation of the dots on the cloud(s).&lt;/p&gt;&lt;p&gt;Hint: Lots of clouds mean poor signal.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Konstellationsdiagramm, berechnet vom ersten Datenblock in einem DAB frame. Angezeigt wird die Konstellation der Träger im dekodierten OFDM Symbol. &lt;/p&gt;&lt;p&gt;Bei DAB sind die Bits kodiert als (1, 1), (1, -1), (-1, -1) und (1,1), daher sind ideallerweise 4 Punkte zu sehen, einer in jeder Ecke. Die Signalqualität ist umgekehrt zu den angezeigten Wolken. Die Nummer unter des &amp;quot;Wolkenbildes&amp;quot; zeigt die Standardabweichung der Punkte in der Wolke.&lt;/p&gt;&lt;p&gt;Bemerkung: Viele Punkte bedeuten schwaches Signal.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quality indicator (experimental). The number shows the standard phase deviation of the decoded signal.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Qualitätsindikator (experimentell). Die Nummer zeigt die Standardphasenabweichung des dekodierten Signals.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../spectrum-viewer/scopewidget.ui" line="14"/>
        <source>spectrumscope</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sdrplayHandler</name>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-handler-v2.cpp" line="823"/>
        <source>Save file ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-handler-v2.cpp" line="825"/>
        <source>Xml (*.uff)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sdrplaySelect</name>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplayselect.cpp" line="41"/>
        <source>RSP select</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sdrplayWidget</name>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="20"/>
        <source>SDRplay control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="28"/>
        <source>mirics-SDRplay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="38"/>
        <source>dump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="58"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Version of the SDRplay library detected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Version der erkannten SDRplay Bibliothek.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="197"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Touch to switch on automatic gain control - based on the setting of the lnastate and the ifgain.&lt;/p&gt;&lt;p&gt;If switched on, the lnastate switch and the ifgain slider are switched off&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Klicken, um die automatische Verstärkungskontrolle (AGC) einzuschalten anhand der Angaben des LNA Status und der IF Verstärkung.&lt;/p&gt;&lt;p&gt;Falls eingeschaltet, ändert sich der LNA Status und die Schieberegler für die IF Verstärkung werden abgeschaltet.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="200"/>
        <source>agc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ppm control. Tells the device the offset (in ppm) of the observed oscillator offset.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;PPM Kontrolle. Übermittelt dem Gerät den Offset (in ppm) des festgestellten Oszillatoroffset.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="340"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select an antenna (RSP-II)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wähle die Antenne aus (RSP-II)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="344"/>
        <source>Antenna A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="349"/>
        <source>Antenna B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="239"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Setting the lna state, determining the gain reduction applied in the lna.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wählen Sie die LNA Einstellung, bestimmt durch die Verstärkungsabnahme im LNA.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="35"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Dumps the raw input from the SDRplay into a self describing file (with header in xml format containing recorded time, container format, frequency, device name, Qt-DAB version)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Opens a &apos;Save as ...&apos; dialog. Press again to stop recording.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Very experimental! The resulting file can be read-in by using the xml file handler (if configured)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Warning: Produces large files!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Speichert die Eingangsrohdaten vom SDRplay in eine selbsterklärende Datei (mit Header im xml-Format, der die Aufnahmezeit, Containerformat, Frequenz, Empfänger, Qt-DAB-Version anzeigt)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Öffnet einen &quot;Speichern unter ...&quot; dialog. Noch einmal klicken, um die Aufnahme zu beenden.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Sehr experimentell! Die erzeugte Datei kann über die xml file Eingangsfunktion geladen werden (falls konfiguriert)&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Warnung: Erstellt große Dateien!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="246"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The display shows the gain reduction in the lna of the device.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Die Anzeige zeigt die Verstärungsabnahme im LNA des Geräts.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="296"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If the device is an rspduo, select the tuner with this combobox&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Falls der Empfänger ein rspduo ist, wählen Sie den Tuner anhand dieser Auswahlbox.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="300"/>
        <source>Tuner 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="305"/>
        <source>Tuner 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="220"/>
        <source>debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="148"/>
        <source>ppm control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="176"/>
        <source>if gain reduction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v2/sdrplay-widget-v2.ui" line="269"/>
        <source>lna state selector</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sdrplayWidget_v3</name>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="20"/>
        <source>SDRplay control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="28"/>
        <source>mirics-SDRplay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="48"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Version of the SDRplay library detected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Version der erkannten SDRplay Bibliothek.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="84"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ppm control. Tells the device the offset (in ppm) of the observed oscillator offset.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;PPM Kontrolle. Übermittelt dem Gerät den Offset (in ppm) des festgestellten Oszillatoroffsets.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="148"/>
        <source>ppm control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="176"/>
        <source>if gain reduction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="197"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Touch to switch on automatic gain control - based on the setting of the lnastate and the ifgain.&lt;/p&gt;&lt;p&gt;If switched on, the lnastate switch and the ifgain slider are switched off&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Klicken, um die automatische Verstärkungskontrolle (AGC) einzuschalten anhand der Angaben des LNA Status und der IF Verstärkung.&lt;/p&gt;&lt;p&gt;Falls eingeschaltet, ändert sich der LNA Status und die Schieberegler für die IF Verstärkung werden abgeschaltet.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="200"/>
        <source>agc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="220"/>
        <source>debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="239"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Setting the lna state, determining the gain reduction applied in the lna.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wählen Sie die LNA Einstellung, bestimmt durch die Verstärkungsabnahme im LNA.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="246"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The display shows the gain reduction in the lna of the device.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Die Anzeige zeigt die Verstärkungsabnahme im LNA des Geräts.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="269"/>
        <source>lna state selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="296"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If the device is an rspduo, select the tuner with this combobox&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Falls der Empfänger ein rspduo ist, wählen Sie den Tuner anhand dieser Auswahlbox.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="300"/>
        <source>Tuner 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="305"/>
        <source>Tuner 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="340"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select an antenna (RSP-II)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Wählen Sie die Antenne aus (RSP-II)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="344"/>
        <source>Antenna A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/sdrplay-handler-v3/sdrplay-widget-v3.ui" line="349"/>
        <source>Antenna B</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>soapyWidget</name>
    <message>
        <location filename="../devices/soapy/soapy-widget.ui" line="14"/>
        <source>soapy control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/soapy/soapy-widget.ui" line="41"/>
        <source>soapy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/soapy/soapy-widget.ui" line="75"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Touch to switch on automatic gain control - based on the setting of the lnastate and the ifgain.&lt;/p&gt;&lt;p&gt;If switched on, the lnastate switch and the ifgain slider are switched off&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Klicken, um die automatische Verstärkungskontrolle (AGC) einzuschalten anhand der Angaben des LNA Status und der IF Verstärkung.&lt;/p&gt;&lt;p&gt;Falls eingeschaltet, ändert sich der LNA Status und die Schieberegler für die IF Verstärkung werden abgeschaltet.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/soapy/soapy-widget.ui" line="78"/>
        <source>agc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/soapy/soapy-widget.ui" line="124"/>
        <location filename="../devices/soapy/soapy-widget.ui" line="137"/>
        <location filename="../devices/soapy/soapy-widget.ui" line="158"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>technical_data</name>
    <message>
        <location filename="../forms/technical_data.ui" line="14"/>
        <source>Technical Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="165"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Language (defined by provider)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sprache (vom Anbieter vorgegeben)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="171"/>
        <source>language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="37"/>
        <source>Start Address of CU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="54"/>
        <source>Used CUs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="185"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;PTY (Program Type)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Programmart (PTy)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="191"/>
        <source>programType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="88"/>
        <source>Bitrate in kBit/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="25"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;Service long label&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;Service long label&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="71"/>
        <source>Subchannel ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="128"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Shows Protection Level and Type (A or B)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zeigt Fehlerschutz und Type (A or B) an&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="134"/>
        <source>uepField</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="151"/>
        <source>ASCTy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="303"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Slideshow (SLS)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ensemble Name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ensemblename&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Frequency in MHz&lt;/p&gt;&lt;p&gt;Only shown when the input is not a pre-recorded file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Frequenz in MHz&lt;/p&gt;&lt;p&gt;Wird nur angezeigt, falls das Gerät nicht eine aufgenommene Datei ist.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quality of FIC decoding, 100 is good&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Qualität der FIC Dekodierung, Ein Wert von 100 is gut.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="247"/>
        <source>Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="237"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Frame errors. Indication of the quality of the DAB+ frame detection. 100 is good.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Framefehler. Qualitätsanzeige der DAB+ Frameerkennung. Ein Wert von 100 is gut.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="264"/>
        <source>RS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="254"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Quality of the DAB+ frames. &lt;/p&gt;&lt;p&gt;Indicator for the amount of times meaning the frames contain more errors than the Reed Solomon correction can correct. &lt;/p&gt;&lt;p&gt;100 is good.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Qualität der DAB+ Frames. &lt;/p&gt;&lt;p&gt;Die Angabe bedeutet, die Frames beinhalten mehr Fehler, als die Reed Solomon Korrektur verarbeiten kann. &lt;/p&gt;&lt;p&gt;Ein Wert von 100 is gut.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="220"/>
        <source>AAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="227"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Indicator of the success rate of handling the AAC frames in the DAB+ transmissions.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Anzeige der Erfolgsrate bei der Verarbeitung der AAC Frames bei DAB+.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="202"/>
        <source>also on FM:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="209"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;Service name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:14pt;&quot;&gt;Servicename&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="28"/>
        <source>programName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="288"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Slide show indicator&lt;/p&gt;&lt;p&gt;Green means MOT frames are received.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Slideshow Indikator&lt;/p&gt;&lt;p&gt;Grün bedeutet, MOT Frames werden empfangen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="291"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;MOT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; color:#ffffff;&quot;&gt;MOT&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="275"/>
        <source>MOT Decoding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;In EN300401 (2017) the possibility of passing transmitter coordinates through the FIC is cancelled.&lt;/p&gt;&lt;p&gt;The numbers given here are an estimate if the mainId and subId as derived from the null period.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Im Standard EN300401 (2017) wurde die Übermittlung von Senderkoordinaten über die FIC herausgenommen..&lt;/p&gt;&lt;p&gt;Die Zahlen (mainId und subId) hier sind eine Schätzung abgeleitet vom Nullperiodensymbol.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="115"/>
        <source>Prot. level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="141"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="158"/>
        <source>Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../forms/technical_data.ui" line="178"/>
        <source>PTY:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>tiiWidget</name>
    <message>
        <location filename="../tii-viewer/tii-widget.ui" line="14"/>
        <source>tii spectrum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tii-viewer/tii-widget.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spectrum display, shows the frequency spectrum from the channel currently being received.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Spectrumanzeige, zeigt das Frequenzspektrum des aktuell emfpangenen Kanals an.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../tii-viewer/tii-widget.ui" line="50"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If more than one transmitter in the SFN can be identified, the (mainId, subId) of the transmitter&lt;/p&gt;&lt;p&gt;is shown.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Falls mehr als eine Sendeanlage im SFN erkannt wird, erfolgt die Anzeige von (mainId, subId) der stärksten Sendeanlage&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>xmlfile_widget</name>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="14"/>
        <source>xmlfiles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="22"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Path and filename to xml-file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Pfad und Dateiname zur xml-Datei&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="25"/>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="80"/>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="97"/>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="118"/>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="131"/>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="138"/>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="145"/>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="152"/>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="159"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="32"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;File progress&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Fortschritt in der Datei&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="46"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Current time in the file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Aktuelle Zeit in der Datei&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="56"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Total recorded time of the file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Gesamtdauer der Datei (in Sekunden)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="70"/>
        <source>recorder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="77"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Shows recording software and version.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zeigt Aufnahmesoftware und Version an.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="87"/>
        <source>deviceName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Shows recording device&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zeigt ursprüngliches Aufnahmegerät an&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="108"/>
        <source>recorded at </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="115"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Shows recording time (it&apos;s not the current time)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Zeigt Aufnahmezeit (nicht die akutelle Zeit)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="170"/>
        <source>nrBits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="177"/>
        <source>nrElements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="184"/>
        <source>samplerate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="191"/>
        <source>frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="202"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Number of bits recorded&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Anzahl der aufgezeichneten Bits&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="222"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Sampling rate in Hz (normally 2048000 Hz)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Samplingrate in Hz (für gewöhnlich 2048000 Hz)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../devices/xml-filereader/xmlfiles.ui" line="235"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Initial frequency of the recorded ensemble (in kHz)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ursprüngliche Frequenz des aufgezeichneten Ensembles (in kHz)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
</TS>
